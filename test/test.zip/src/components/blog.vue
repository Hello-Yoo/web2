<template>
    <div>
<div class="header">
		<div class="header_c inner_c">
			<h1 class="logo">
				青竹商城
			</h1>
			<dl class = "allType">
				<dt><a href="#">查看所有类型</a></dt>
				<dd>
					<div class = "dd_inn">
						<ul class = "dd_cont">
							<li><a href="#">不锈钢</a></li>
							<li><a href="#">原料水泥</a></li>
							<li><a href="#">塑料</a></li>
							<li><a href="#">木质</a></li>
							<li><a href="#">陶瓷</a></li>
						</ul>
						<ul class="pro">
							<li>
								<a href="#">
									<div class="pic">
										<img src="./images/img25.png" alt="">
									</div>
									<div class="content">
										<h3>简约木质餐盘</h3>
										<span>￥200</span>
									</div>
								</a>
								<div class="mask">
									<a href="#" class = "btn">查看详情</a>
								</div>
							</li>
							<li>
								<a href="#">
									<div class="pic">
										<img src="./images/img26.png" alt="">
									</div>
									<div class="content">
										<h3>简约木质餐盘</h3>
										<span>￥200</span>
									</div>
								</a>
								<div class="mask">
									<a href="#" class = "btn">查看详情</a>
								</div>
							</li>
							<li>
								<a href="#">
									<div class="pic">
										<img src="./images/img27.png" alt="">
									</div>
									<div class="content">
										<h3>简约木质餐盘</h3>
										<span>￥200</span>
									</div>
								</a>
								<div class="mask">
									<a href="#" class = "btn">查看详情</a>
								</div>
							</li>
						</ul>
					</div>
				</dd>
			</dl>
			<ul class="nav">
                
				<li><a href="./index">首页</a></li>
				<li><a href="./allproducts">所有产品</a></li>
				<li><a href="./blog">博客</a></li>
				<li><a href="./article">文章列表</a></li>
			</ul>
			<a href="#" class="search"></a>
			<div class="reg">
				<div class="ico">
					<span class = "ico_c"></span>
					<div class="settle">
						<p class="con">0件商品 共计：<span>￥0</span></p>
						<a href="./shop" class="btn">结算</a>
					</div>
					<span class = "con">
						0
					</span>
				</div>
				<div class = "reg_c">
					<a href="./land" id="">登陆</a>
					<span>&nbsp;|&nbsp;</span>
					<a href="./registe">注册</a>
				</div>
			</div>
		</div>
	</div>
	<!-- header部分结束 -->
	<div class="s_content">
		<div class="s_content_c inner_c">
			<div class="s_info">
				<ul class="left">
					<li>
						<div class="show">
							<a href="#">
								<img src="./images/s.jpeg" alt="">
							</a>
						</div>
						<div class="data">
							<div class="nickname">
								<a href="#">
									<img src="./images/img61.png" alt="">
									<span>青竹</span>
								</a>
							</div>
							<div class="date">
								<span>2017-01-19 17:41</span>
							</div>
						</div>
					</li>
					<li>
						<div class="show">
							<a href="#">
								<img src="./images/g.jpeg" alt="">
							</a>
						</div>
						<div class="data">
							<div class="nickname">
								<a href="#">
									<img src="./images/img61.png" alt="">
									<span>青竹</span>
								</a>
							</div>
							<div class="date">
								<span>2017-01-19 17:41</span>
							</div>
						</div>
					</li>
					<li>
						<div class="show">
							<a href="#">
								<div class="art">
									<h5>当轻博客遇见电商</h5>
									<p class = "sub">
										欢迎使用友好速搭，你看到的这个版块是轻博客功能，它能让你更好地展示和传播你的理念。现在简单介绍下这个功能，你可以新建4种轻博客内容：文字博客图片博客音乐博客视频博客友好速搭轻博客作为独立网站的功能之一，它将是实现你轻流量入口的重要一步。我们意在为你营造一个温暖的氛围，和冷冰冰的电商说再见。在做优雅有温度的生意的同时，写下你的故事，分享你的心情。让店铺中的每一件商品都赋有鲜活的生命力。将你的故事心情、优美的图片、有共鸣的音乐以及心动的视频随时随地分享至微博或朋友圈等平台，会有更多的人看到你和你独立
									</p>
								</div>
							</a>
						</div>
						<div class="data">
							<div class="nickname">
								<a href="#">
									<img src="./images/img61.png" alt="">
									<span>青竹</span>
								</a>
							</div>
							<div class="date">
								<span>2017-01-19 17:41</span>
							</div>
						</div>
					</li>
				</ul>
				<ul class="right">
					<li>
						<div class="show">
							<a href="#">
								<img src="./images/s.jpeg" alt="">
							</a>
						</div>
						<div class="data">
							<div class="nickname">
								<a href="#">
									<img src="./images/img61.png" alt="">
									<span>青竹</span>
								</a>
							</div>
							<div class="date">
								<span>2017-01-19 17:41</span>
							</div>
						</div>
					</li>
					<li>
						<div class="show">
							<a href="#">
								<img src="./images/s.jpeg" alt="">
							</a>
						</div>
						<div class="data">
							<div class="nickname">
								<a href="#">
									<img src="./images/img61.png" alt="">
									<span>青竹</span>
								</a>
							</div>
							<div class="date">
								<span>2017-01-19 17:41</span>
							</div>
						</div>
					</li>
				</ul>
			</div>
		</div>
	</div>
	<!-- footer部分开始 -->
	<div class="footer">
		<div class="footer_c inner_c">
			<div class="footer_top">
				<div class="bir">
					<a href="#">
						<img src="./images/logo.png" alt="">
					</a>
					<div class="info">
						青竹良品原创生活类电商品牌，秉承一贯的严谨态度，我们深入世界各地，从源头全程严格把控商品生产环节，力求帮消费者甄选到最优质的商品，全线采用天然原材料，控制甲醛低量无害，采用进口工艺，国际生产线不断优化，食材保证核心原产地新鲜直供，让你享受品质生活
					</div>
				</div>
				<div class="about">
					<dl>
						<dt>
							<a href="#">
								关于我们
							</a>
						</dt>
						<dd>
							<a href="#">
								我的品牌
							</a>
						</dd>
						<dd>
							<a href="#">
								公司动态
							</a>
						</dd>
						<dd>
							<a href="#">
								经历发展
							</a>
						</dd>
						<dd>
							<a href="#">
								商品推广
							</a>
						</dd>
					</dl>
					<dl>
						<dt>
							<a href="#">
								关于我们
							</a>
						</dt>
						<dd>
							<a href="#">
								我的品牌
							</a>
						</dd>
						<dd>
							<a href="#">
								公司动态
							</a>
						</dd>
						<dd>
							<a href="#">
								经历发展
							</a>
						</dd>
						<dd>
							<a href="#">
								商品推广
							</a>
						</dd>
					</dl>
					<dl>
						<dt>
							<a href="#">
								关于我们
							</a>
						</dt>
						<dd>
							<a href="#">
								我的品牌
							</a>
						</dd>
						<dd>
							<a href="#">
								公司动态
							</a>
						</dd>
						<dd>
							<a href="#">
								经历发展
							</a>
						</dd>
						<dd>
							<a href="#">
								商品推广
							</a>
						</dd>
					</dl>
				</div>
				<div class="ewm">
					<p class="wx">
						<img src="./images/img71.png" alt="">
						<span>微信公众号</span>
					</p>
					<p class="wb">
						<img src="./images/img72.png" alt="">
						<span>微博公众号</span>
					</p>
				</div>
			</div>
		</div>
		<div class="footer_bar">
			<div class="footer_bar_c inner_c">
				<div class = "pay">
					<p class = "copy">
						2019 © youhaosuda.com
					</p>
					<p class = "ico">
						<a href="#">
							<img src="./images/img81.png" alt="">
						</a>
						<a href="#">
							<img src="./images/img82.png" alt="">
						</a>
						<a href="#">
							<img src="./images/img83.png" alt="">
						</a>
						<a href="#">
							<img src="./images/img84.png" alt="">
						</a>
						<a href="#">
							<img src="./images/img85.png" alt="">
						</a>
						<a href="#">
							<img src="./images/img86.png" alt="">
						</a>
						<a href="#">
							<img src="./images/img87.png" alt="">
						</a>
					</p>
				</div>
				<div class="super">
					<a href="#" class = "pic1">
						
					</a>
					<a href="#" class = "pic2">
						
					</a>
					<a href="#" class = "pic3">
						
					</a>
				</div>
			</div>
		</div>
	</div>
	<!-- 返回顶部 -->
	<div class="lingpin_top">
		<a href="#" class = "qq">QQ<br/>客服</a>
		<a href="#" class = "wx">微信<br/>客服</a>
		<a href="#" class = "top_c">↑</a>
	</div>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style scoped>
@import '../assets/common.css';
@import '../assets/reset.css';
@import '../assets/blog.css';
</style>