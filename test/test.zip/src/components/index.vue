<template>
    <div>
<div class="header">
		<div class="header_c inner_c">
			<h1 class="logo">
				青竹商城
			</h1>
			<dl class = "allType">
				<dt><a href="#">查看所有类型</a></dt>
				<dd>
					<div class = "dd_inn">
						<ul class = "dd_cont">
							<li><a href="#">不锈钢</a></li>
							<li><a href="#">原料水泥</a></li>
							<li><a href="#">塑料</a></li>
							<li><a href="#">木质</a></li>
							<li><a href="#">陶瓷</a></li>
						</ul>
						<ul class="pro">
							<li>
								<a href="#">
									<div class="pic">
										<img src="./images/img25.png" alt="">
									</div>
									<div class="content">
										<h3>简约木质餐盘</h3>
										<span>￥200</span>
									</div>
								</a>
								<div class="mask">
									<a href="#" class = "btn">查看详情</a>
								</div>
							</li>
							<li>
								<a href="#">
									<div class="pic">
										<img src="./images/img26.png" alt="">
									</div>
									<div class="content">
										<h3>简约木质餐盘</h3>
										<span>￥200</span>
									</div>
								</a>
								<div class="mask">
									<a href="#" class = "btn">查看详情</a>
								</div>
							</li>
							<li>
								<a href="#">
									<div class="pic">
										<img src="./images/img27.png" alt="">
									</div>
									<div class="content">
										<h3>简约木质餐盘</h3>
										<span>￥200</span>
									</div>
								</a>
								<div class="mask">
									<a href="#" class = "btn">查看详情</a>
								</div>
							</li>
						</ul>
					</div>
				</dd>
			</dl>
			<ul class="nav">
				<li><a href="./index">首页</a></li>
				<li><a href="./allproducts">所有产品</a></li>
				<li><a href="./blog">博客</a></li>
				<li><a href="./article">文章列表</a></li>
			</ul>
			<a href="#" class="search"></a>
			<div class="reg">
				<div class="ico">
					<span class = "ico_c"></span>
					<div class="settle">
						<p class="con">0件商品 共计：<span>￥0</span></p>
						<a href="./shop" class="btn">结算</a>
					</div>
					<span class = "con">
						0
					</span>
				</div>
				<div class = "reg_c">
					<a href="./personal" id="">欢迎{{user}}</a>
				</div>
			</div>
		</div>
	</div>
	<!-- header部分结束 -->
	<!-- banner部分开始 -->
	<div class="banner">
		<ul class="pic">
			<li class = "cur"><a href="#"><img src="./images/img11.png" alt=""></a></li>
			<li><a href="#"><img src="./images/img12.png" alt=""></a></li>
			<li><a href="#"><img src="./images/img13.png" alt=""></a></li>
		</ul>
		<ol class = "circle">
			<li class = "cur"></li>
			<li></li>
			<li></li>
		</ol>
	</div>
	<!-- banner部分结束 -->
	<!-- qingzhu_content部分开始 -->
	<div class="qingzhu_content">
		<div class="qingzhu_content_c inner_c">
			<div class="pro1">
				<div class="title">
					<h2><a href="#">新品推荐，精心挑选</a></h2>
					<p class="info">家居必备使用小单品</p>
				</div>
				<div class="pro_pic">
					<div class="pro_c">
						<ul>
							<li>
								<a href="#">
									<img src="./images/img23.png" alt="">
									<div class="cont">
										<h3>黑陶自然花香蜡烛</h3>
                                        <span>￥300</span>
									</div>
								</a>
							</li>
							<li>
								<a href="#">
									<img src="./images/img24.png" alt="">
									<div class="cont">
										<h3>黑陶自然花香蜡烛</h3>
                                        <span>￥300</span>
									</div>
								</a>
							</li>
							<li>
								<a href="#">
									<img src="./images/img25.png" alt="">
									<div class="cont">
										<h3>黑陶自然花香蜡烛</h3>
                                        <span>￥300</span>
									</div>
								</a>
							</li>
							<li>
								<a href="#">
									<img src="./images/img26.png" alt="">
									<div class="cont">
										<h3>黑陶自然花香蜡烛</h3>
                                        <span>￥300</span>
									</div>
								</a>
							</li>
						</ul>
					</div>
					<div class="btns">
						<a href="#" class="leftBtn">&lt;</a>
						<a href="#" class="rightBtn">&gt;</a>
					</div>
				</div>
			</div>
			<div class="pro2">
				<div class="title">
					<h2><a href="#">专题活动，限时促销</a></h2>
					<p class="info">严选材质，用心设计</p>
				</div>
				<div class="pro2_c">
					<ul class = "pro2_c_pic">
						<li class = "pic1 pic">
							<a href="#">
								<img src="./images/img31.jpg" alt="">
							</a>
							<span></span>
						</li>
						<li class = "pic2 pic">
							<a href="#">
								<img src="./images/img32.jpg" alt="">
							</a>
							<span></span>
						</li>
						<li class = "pic3 pic">
							<a href="#">
								<img src="./images/img33.jpg" alt="">
							</a>
							<span></span>
						</li>
					</ul>
				</div>
			</div>
			<div class="pro3">
				<div class="title">
					<h2><a href="#">青竹良品，你的家居首选</a></h2>
					<p class="info">天然之源，诚挚之礼</p>
				</div>
				<div class="pro3_c">
					<ul  class = "pub_pro">
						<li>
							<a href="#">
								<img src="./images/img40.jpg" alt="">
							</a>
							<div class="mask"></div>
						</li>
						<li>
							<a href="#">
								<img src="./images/img41.png" alt="">
								<div class="cont">
									<h3>简约时尚水泥花瓶</h3>
									<span>￥450</span>
								</div>
							</a>
							<div class="mask">
								<a href="#" class = "btn">
									查看详情
								</a>
							</div>
						</li>
						
						<li>
							<a href="#">
								<img src="./images/img42.png" alt="">
								<div class="cont">
									<h3>简约时尚水泥花瓶</h3>
									<span>￥450</span>
								</div>
							</a>
							<div class="mask">
								<a href="#" class = "btn">
									查看详情
								</a>
							</div>
						</li>
						<li>
							<a href="#">
								<img src="./images/img43.png" alt="">
								<div class="cont">
									<h3>简约时尚水泥花瓶</h3>
									<span>￥450</span>
								</div>
							</a>
							<div class="mask">
								<a href="#" class = "btn">
									查看详情
								</a>
							</div>
						</li>
						<li>
							<a href="#">
								<img src="./images/img44.png" alt="">
								<div class="cont">
									<h3>简约时尚水泥花瓶</h3>
									<span>￥450</span>
								</div>
							</a>
							<div class="mask">
								<a href="#" class = "btn">
									查看详情
								</a>
							</div>
						</li>
					</ul>
					<ul  class = "pub_pro">
						<li>
							<a href="#">
								<img src="./images/img45.jpg" alt="">
							</a>
							<div class="mask">
							</div>
						</li>
						<li>
							<a href="#">
								<img src="./images/img46.png" alt="">
								<div class="cont">
									<h3>简约时尚水泥花瓶</h3>
									<span>￥450</span>
								</div>
							</a>
							<div class="mask">
								<a href="#" class = "btn">
									查看详情
								</a>
							</div>
						</li>
						
						<li>
							<a href="#">
								<img src="./images/img47.png" alt="">
								<div class="cont">
									<h3>简约时尚水泥花瓶</h3>
									<span>￥450</span>
								</div>
							</a>
							<div class="mask">
								<a href="#" class = "btn">
									查看详情
								</a>
							</div>
						</li>
						<li>
							<a href="#">
								<img src="./images/img48.png" alt="">
								<div class="cont">
									<h3>简约时尚水泥花瓶</h3>
									<span>￥450</span>
								</div>
							</a>
							<div class="mask">
								<a href="#" class = "btn">
									查看详情
								</a>
							</div>
						</li>
						<li>
							<a href="#">
								<img src="./images/img49.png" alt="">
								<div class="cont">
									<h3>简约时尚水泥花瓶</h3>
									<span>￥450</span>
								</div>
							</a>
							<div class="mask">
								<a href="#" class = "btn">
									查看详情
								</a>
							</div>
						</li>
					</ul>
				</div>
			</div>
			<div class="pro4">
				<div class="title">
					<h2><a href="#">全球大牌优选，买手用心挑选</a></h2>
					<p class="info">全球好货，原装正品</p>
				</div>
				<div class="por4_top">
					<div class="pic1 pic">
						<img src="./images/img51.jpg" alt="">
						<span></span>
					</div>
					<div class="pic2">
						<div class="top pic">
							<img src="./images/img52.jpg" alt="">
							<span></span>
						</div>
						<div class="bottom pic">
							<img src="./images/img53.jpg" alt="">
							<span></span>
						</div>
					</div>
					<div class="pic3 pic">
						<img src="./images/img54.jpg" alt="">
						<span></span>
					</div>
				</div>
				<div class="pro4_bottom">
					<ul class="pro4_c">
						<li>
							<div class="pic">
								<a href="#">
									<img src="./images/img55.png" alt="">
								</a>
							</div>
							<p class="cont">
								<a href="#">
									自然生活，精选用料
								</a>
							</p>
						</li>
						<li>
							<div class="pic">
								<a href="#">
									<img src="./images/img56.png" alt="">
								</a>
							</div>
							<p class="cont">
								<a href="#">
									自然生活，精选用料
								</a>
							</p>
						</li>
						<li>
							<div class="pic">
								<a href="#">
									<img src="./images/img57.png" alt="">
								</a>
							</div>
							<p class="cont">
								<a href="#">
									自然生活，精选用料
								</a>
							</p>
						</li>
						<li>
							<div class="pic">
								<a href="#">
									<img src="./images/img58.png" alt="">
								</a>
							</div>
							<p class="cont">
								<a href="#">
									自然生活，精选用料
								</a>
							</p>
						</li>
						<li>
							<div class="pic">
								<a href="#">
									<img src="./images/img59.png" alt="">
								</a>
							</div>
							<p class="cont">
								<a href="#">
									自然生活，精选用料
								</a>
							</p>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<!-- qingzhu_content部分结束 -->
	<!-- liangpin部分开始 -->
	<div class="liangpin">
		<div class="liangpin_c inner_c">
			<div class="title">
				<h2><a href="#">良品体验</a></h2>
				<p class="info">用户反馈，是我们改进的目标</p>
			</div>
			<div class="lp_pro">
				<ul>
					<li>
						<a href="#" title="">
							<img src="./images/img61.png" alt="">
						</a>
						<div class="cont">
							<div class="tit">
								<h4>天草陶石咖啡杯套装</h4>
								<span>￥299</span>
							</div>
							<p class = "info">
								使用了粉碎高品质的天草陶石后提炼而成的土，制作了泛着淡青色的白瓷。用餐时可以记住食品名称、体会新鲜口味···可对颜色和口味、气味、口感逐个品味，从中感受用餐的乐趣，同时还可自然而然地了解日本饮食文化
							</p>
							<p class="time">
								<span>alice</span>
								<span>2016-12-16</span>
								<span>09:59</span>
							</p>
						</div>
					</li>
					<li>
						<a href="#" title="">
							<img src="./images/img62.png" alt="">
						</a>
						<div class="cont">
							<div class="tit">
								<h4>天草陶石咖啡杯套装</h4>
								<span>￥299</span>
							</div>
							<p class = "info">
								使用了粉碎高品质的天草陶石后提炼而成的土，制作了泛着淡青色的白瓷。用餐时可以记住食品名称、体会新鲜口味···可对颜色和口味、气味、口感逐个品味，从中感受用餐的乐趣，同时还可自然而然地了解日本饮食文化
							</p>
							<p class="time">
								<span>alice</span>
								<span>2016-12-16</span>
								<span>09:59</span>
							</p>
						</div>
					</li>
					<li>
						<a href="#" title="">
							<img src="./images/img63.png" alt="">
						</a>
						<div class="cont">
							<div class="tit">
								<h4>天草陶石咖啡杯套装</h4>
								<span>￥299</span>
							</div>
							<p class = "info">
								使用了粉碎高品质的天草陶石后提炼而成的土，制作了泛着淡青色的白瓷。用餐时可以记住食品名称、体会新鲜口味···可对颜色和口味、气味、口感逐个品味，从中感受用餐的乐趣，同时还可自然而然地了解日本饮食文化
							</p>
							<p class="time">
								<span>alice</span>
								<span>2016-12-16</span>
								<span>09:59</span>
							</p>
						</div>
					</li>
					<li>
						<a href="#" title="">
							<img src="./images/img64.png" alt="">
						</a>
						<div class="cont">
							<div class="tit">
								<h4>天草陶石咖啡杯套装</h4>
								<span>￥299</span>
							</div>
							<p class = "info">
								使用了粉碎高品质的天草陶石后提炼而成的土，制作了泛着淡青色的白瓷。用餐时可以记住食品名称、体会新鲜口味···可对颜色和口味、气味、口感逐个品味，从中感受用餐的乐趣，同时还可自然而然地了解日本饮食文化
							</p>
							<p class="time">
								<span>alice</span>
								<span>2016-12-16</span>
								<span>09:59</span>
							</p>
						</div>
					</li>
				</ul>
			</div>
		</div>
	</div>
	<!-- liangpin部分结束 -->
	<!-- footer部分开始 -->
	<div class="footer">
		<div class="footer_c inner_c">
			<div class="footer_top">
				<div class="bir">
					<a href="#">
						<img src="./images/logo.png" alt="">
					</a>
					<div class="info">
						青竹良品原创生活类电商品牌，秉承一贯的严谨态度，我们深入世界各地，从源头全程严格把控商品生产环节，力求帮消费者甄选到最优质的商品，全线采用天然原材料，控制甲醛低量无害，采用进口工艺，国际生产线不断优化，食材保证核心原产地新鲜直供，让你享受品质生活
					</div>
				</div>
				<div class="about">
					<dl>
						<dt>
							<a href="#">
								关于我们
							</a>
						</dt>
						<dd>
							<a href="#">
								我的品牌
							</a>
						</dd>
						<dd>
							<a href="#">
								公司动态
							</a>
						</dd>
						<dd>
							<a href="#">
								经历发展
							</a>
						</dd>
						<dd>
							<a href="#">
								商品推广
							</a>
						</dd>
					</dl>
					<dl>
						<dt>
							<a href="#">
								关于我们
							</a>
						</dt>
						<dd>
							<a href="#">
								我的品牌
							</a>
						</dd>
						<dd>
							<a href="#">
								公司动态
							</a>
						</dd>
						<dd>
							<a href="#">
								经历发展
							</a>
						</dd>
						<dd>
							<a href="#">
								商品推广
							</a>
						</dd>
					</dl>
					<dl>
						<dt>
							<a href="#">
								关于我们
							</a>
						</dt>
						<dd>
							<a href="#">
								我的品牌
							</a>
						</dd>
						<dd>
							<a href="#">
								公司动态
							</a>
						</dd>
						<dd>
							<a href="#">
								经历发展
							</a>
						</dd>
						<dd>
							<a href="#">
								商品推广
							</a>
						</dd>
					</dl>
				</div>
				<div class="ewm">
					<p class="wx">
						<img src="./images/img71.png" alt="">
						<span>微信公众号</span>
					</p>
					<p class="wb">
						<img src="./images/img72.png" alt="">
						<span>微博公众号</span>
					</p>
				</div>
			</div>
		</div>
		<div class="footer_bar">
			<div class="footer_bar_c inner_c">
				<div class = "pay">
					<p class = "copy">
						2019 © youhaosuda.com
					</p>
					<p class = "ico">
						<a href="#">
							<img src="./images/img81.png" alt="">
						</a>
						<a href="#">
							<img src="./images/img82.png" alt="">
						</a>
						<a href="#">
							<img src="./images/img83.png" alt="">
						</a>
						<a href="#">
							<img src="./images/img84.png" alt="">
						</a>
						<a href="#">
							<img src="./images/img85.png" alt="">
						</a>
						<a href="#">
							<img src="./images/img86.png" alt="">
						</a>
						<a href="#">
							<img src="./images/img87.png" alt="">
						</a>
					</p>
				</div>
				<div class="super">
					<a href="#" class = "pic1">
						
					</a>
					<a href="#" class = "pic2">
						
					</a>
					<a href="#" class = "pic3">
						
					</a>
				</div>
			</div>
		</div>
	</div>
	<!-- 返回顶部 -->
	<div class="lingpin_top">
		<a href="#" class = "qq">QQ<br/>客服</a>
		<a href="#" class = "wx">微信<br/>客服</a>
		<a href="#" class = "top_c">↑</a>
	</div>
    </div>
</template>

<script>
import axios from 'axios'
    export default {
        data() {
			return {
				user:''
			}
		},
		created() {
			axios({
				method:'get',
				url:this.globalAPI.user_info,
				headers:{
					'accesstoken':sessionStorage.accesstoken
				},
			}).then((ref)=>{
						
				console.log(ref)
			this.user=ref.data.data.userName
			}).catch((error)=>{
				console.log(error)
			});

		},
    }
</script>

<style scoped>
@import '../assets/common.css';
@import '../assets/reset.css';
@import '../assets/index.css';
</style>