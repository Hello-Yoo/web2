$("#shop").mouseenter(function(){
    $(".shop").slideToggle();
})
