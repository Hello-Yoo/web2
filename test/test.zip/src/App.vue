<template>
  <div >

    <router-view/>
  </div>
</template>

<style lang="less">

</style>
