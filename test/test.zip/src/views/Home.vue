<template>
  <Land></Land>
   
</template>

<script>
import Land from '../components/land.vue'

export default {
  components: { Land },
  
  
};
</script>
<style>
</style>
